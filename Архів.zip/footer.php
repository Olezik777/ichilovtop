<?php
/**
 * Footer template.
 *
 * @package IchilovTop
 */

if (! defined('ABSPATH')) {
	exit;
}
?>
	</main>

	<footer class="site-footer">
		<div class="container site-footer__inner">
			<div class="site-footer__info">
				<p><strong><?php bloginfo('name'); ?></strong></p>
				<p><?php echo esc_html(get_bloginfo('description')); ?></p>
			</div>

			<nav class="footer-menu" aria-label="<?php esc_attr_e('Footer menu', 'ichilovtop'); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'fallback_cb'    => 'wp_page_menu',
						'menu_class'     => 'menu',
					)
				);
				?>
			</nav>
		</div>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
