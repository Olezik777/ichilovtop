<?php
/**
 * Theme functions for Ichilov Top.
 *
 * @package IchilovTop
 */

if (! defined('ABSPATH')) {
	exit;
}

function ichilovtop_theme_setup() {
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

	register_nav_menus(
		array(
			'primary' => __('Primary Menu', 'ichilovtop'),
			'footer'  => __('Footer Menu', 'ichilovtop'),
		)
	);
}
add_action('after_setup_theme', 'ichilovtop_theme_setup');

function ichilovtop_enqueue_assets() {
	wp_enqueue_style('ichilovtop-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
}
add_action('wp_enqueue_scripts', 'ichilovtop_enqueue_assets');

add_filter('use_block_editor_for_post', '__return_false', 100);
add_filter('use_block_editor_for_post_type', '__return_false', 100);
add_filter('gutenberg_can_edit_post', '__return_false', 100);
add_filter('gutenberg_can_edit_post_type', '__return_false', 100);

function ichilovtop_disable_block_widgets() {
	remove_theme_support('widgets-block-editor');
}
add_action('after_setup_theme', 'ichilovtop_disable_block_widgets');

function ichilovtop_get_field($field_name, $default = '', $post_id = false) {
	if (function_exists('get_field')) {
		$value = get_field($field_name, $post_id);

		if ($value !== null && $value !== false && $value !== '') {
			return $value;
		}
	}

	return $default;
}

function ichilovtop_get_image_url($field_name, $default = '', $post_id = false, $size = 'large') {
	$image = function_exists('get_field') ? get_field($field_name, $post_id) : null;

	if (is_array($image)) {
		if (! empty($image['sizes'][$size])) {
			return $image['sizes'][$size];
		}

		if (! empty($image['url'])) {
			return $image['url'];
		}
	}

	if (is_numeric($image)) {
		$url = wp_get_attachment_image_url((int) $image, $size);
		if ($url) {
			return $url;
		}
	}

	if (is_string($image) && $image !== '') {
		return $image;
	}

	return $default;
}

function ichilovtop_get_repeater($field_name, $default = array(), $post_id = false) {
	$value = function_exists('get_field') ? get_field($field_name, $post_id) : null;
	return is_array($value) && ! empty($value) ? $value : $default;
}

function ichilovtop_default_front_page_content() {
	return array(
		'hero_stats' => array(
			array(
				'value' => '1250+',
				'label' => __('врачей и специалистов международного уровня', 'ichilovtop'),
			),
			array(
				'value' => '10 000+',
				'label' => __('иностранных пациентов ежегодно', 'ichilovtop'),
			),
			array(
				'value' => '3-5 дней',
				'label' => __('на комплексную диагностику и второе мнение', 'ichilovtop'),
			),
		),
		'hero_badges' => array(
			array(
				'title' => __('Лечение без посредников', 'ichilovtop'),
				'text'  => __('Координация через международный отдел клиники с прозрачной организацией процесса.', 'ichilovtop'),
			),
			array(
				'title' => __('Современная диагностика', 'ichilovtop'),
				'text'  => __('Высокоточные протоколы обследования и персонализированный план лечения.', 'ichilovtop'),
			),
			array(
				'title' => __('Поддержка иностранных пациентов', 'ichilovtop'),
				'text'  => __('Трансфер, перевод, сопровождение и помощь в логистике на всех этапах.', 'ichilovtop'),
			),
		),
		'advantages' => array(
			array(
				'title' => __('Лицензированная клиника', 'ichilovtop'),
				'text'  => __('Международный отдел помогает организовать лечение напрямую и без лишних посредников.', 'ichilovtop'),
			),
			array(
				'title' => __('Новейшее оборудование', 'ichilovtop'),
				'text'  => __('Диагностика и терапия выполняются на современном оборудовании экспертного уровня.', 'ichilovtop'),
			),
			array(
				'title' => __('Поэтапная оплата', 'ichilovtop'),
				'text'  => __('Финансовый план прозрачен: пациент оплачивает только назначенные процедуры.', 'ichilovtop'),
			),
			array(
				'title' => __('Медицинское сопровождение', 'ichilovtop'),
				'text'  => __('Координаторы остаются на связи до, во время и после завершения лечения.', 'ichilovtop'),
			),
		),
		'treatments' => array(
			array(
				'title' => __('Онкология', 'ichilovtop'),
				'text'  => __('Персонализированные схемы терапии, хирургия, радиотерапия и второе мнение экспертов.', 'ichilovtop'),
			),
			array(
				'title' => __('Кардиология и кардиохирургия', 'ichilovtop'),
				'text'  => __('Комплексная диагностика сердца, лечение сложных сердечно-сосудистых заболеваний.', 'ichilovtop'),
			),
			array(
				'title' => __('Нейрохирургия и неврология', 'ichilovtop'),
				'text'  => __('Высокоточная диагностика и малоинвазивные нейрохирургические вмешательства.', 'ichilovtop'),
			),
			array(
				'title' => __('Ортопедия и травматология', 'ichilovtop'),
				'text'  => __('Эндопротезирование, спортивная медицина, восстановление опорно-двигательной системы.', 'ichilovtop'),
			),
			array(
				'title' => __('Гинекология и репродуктивная медицина', 'ichilovtop'),
				'text'  => __('Лечение гинекологических заболеваний и экспертные программы для женщин.', 'ichilovtop'),
			),
			array(
				'title' => __('Педиатрия', 'ichilovtop'),
				'text'  => __('Диагностика и лечение детей в профильных отделениях с международным сопровождением.', 'ichilovtop'),
			),
		),
		'diagnostics' => array(
			array(
				'title' => __('Экспресс-диагностика за 3-5 дней', 'ichilovtop'),
				'text'  => __('Сжатые сроки обследования без потери качества и клинической точности.', 'ichilovtop'),
			),
			array(
				'title' => __('Второе мнение профессора', 'ichilovtop'),
				'text'  => __('Пересмотр диагноза и подтверждение тактики лечения ведущими специалистами.', 'ichilovtop'),
			),
			array(
				'title' => __('Индивидуальный маршрут пациента', 'ichilovtop'),
				'text'  => __('Все исследования и консультации выстраиваются в понятную, заранее согласованную схему.', 'ichilovtop'),
			),
		),
		'steps' => array(
			array(
				'title' => __('Заявка', 'ichilovtop'),
				'text'  => __('Вы отправляете запрос и медицинские документы через сайт или мессенджер.', 'ichilovtop'),
			),
			array(
				'title' => __('Предварительная оценка', 'ichilovtop'),
				'text'  => __('Координатор и профильный специалист изучают случай и предлагают маршрут.', 'ichilovtop'),
			),
			array(
				'title' => __('План и смета', 'ichilovtop'),
				'text'  => __('Вы получаете сроки, ориентировочную стоимость и перечень процедур.', 'ichilovtop'),
			),
			array(
				'title' => __('Приезд в Израиль', 'ichilovtop'),
				'text'  => __('Организуем трансфер, перевод, запись к врачам и бытовое сопровождение.', 'ichilovtop'),
			),
			array(
				'title' => __('Лечение и контроль', 'ichilovtop'),
				'text'  => __('После очных процедур остаемся на связи и помогаем с дальнейшими рекомендациями.', 'ichilovtop'),
			),
		),
		'price_items' => array(
			array(
				'item' => __('Предварительная консультация и разбор документов', 'ichilovtop'),
			),
			array(
				'item' => __('Индивидуальный план диагностики или лечения', 'ichilovtop'),
			),
			array(
				'item' => __('Поддержка международного координатора', 'ichilovtop'),
			),
			array(
				'item' => __('Прозрачная стоимость без скрытых этапов', 'ichilovtop'),
			),
		),
		'international_benefits' => array(
			array(
				'title' => __('Персональный координатор', 'ichilovtop'),
				'text'  => __('Один контактный человек сопровождает пациента от первой заявки до завершения программы.', 'ichilovtop'),
			),
			array(
				'title' => __('Перевод и документы', 'ichilovtop'),
				'text'  => __('Помогаем с переводом заключений, выписок и общением с медицинской командой.', 'ichilovtop'),
			),
			array(
				'title' => __('Логистика поездки', 'ichilovtop'),
				'text'  => __('Поддержка с трансфером, проживанием и организационными вопросами в Израиле.', 'ichilovtop'),
			),
		),
		'faq' => array(
			array(
				'question' => __('Можно ли получить предварительное мнение дистанционно?', 'ichilovtop'),
				'answer'   => __('Да. Вы можете отправить документы онлайн, после чего координатор поможет организовать предварительный разбор случая и предложит дальнейшие шаги.', 'ichilovtop'),
			),
			array(
				'question' => __('Сколько времени занимает диагностика?', 'ichilovtop'),
				'answer'   => __('Во многих программах ключевые обследования можно пройти в течение 3-5 рабочих дней, в зависимости от профиля заболевания.', 'ichilovtop'),
			),
			array(
				'question' => __('Помогаете ли вы с проживанием и трансфером?', 'ichilovtop'),
				'answer'   => __('Да. Международный отдел координирует трансфер, размещение и бытовые вопросы, чтобы пациент сосредоточился на лечении.', 'ichilovtop'),
			),
			array(
				'question' => __('Как формируется стоимость лечения?', 'ichilovtop'),
				'answer'   => __('После оценки документов составляется предварительный план с ориентировочной стоимостью, а оплата проходит поэтапно по мере выполнения услуг.', 'ichilovtop'),
			),
		),
	);
}

function ichilovtop_register_acf_fields() {
	if (! function_exists('acf_add_local_field_group')) {
		return;
	}

	acf_add_local_field_group(
		array(
			'key'    => 'group_ichilovtop_front_page',
			'title'  => __('Ichilov Top Front Page', 'ichilovtop'),
			'fields' => array(
				array(
					'key'   => 'field_ich_hero_tab',
					'label' => __('Hero', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_hero_eyebrow',
					'label'         => __('Hero Eyebrow', 'ichilovtop'),
					'name'          => 'hero_eyebrow',
					'type'          => 'text',
					'default_value' => __('Лечение в Израиле без посредников', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_hero_title',
					'label'         => __('Hero Title', 'ichilovtop'),
					'name'          => 'hero_title',
					'type'          => 'text',
					'default_value' => __('Ichilov Top: диагностика и лечение в ведущем медицинском центре Израиля', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_hero_text',
					'label'         => __('Hero Text', 'ichilovtop'),
					'name'          => 'hero_text',
					'type'          => 'textarea',
					'rows'          => 4,
					'default_value' => __('Организуем обследование, второе мнение и лечение у профильных специалистов с прозрачной координацией для иностранных пациентов.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_primary_button_text',
					'label'         => __('Primary Button Text', 'ichilovtop'),
					'name'          => 'hero_primary_button_text',
					'type'          => 'text',
					'default_value' => __('Получить план лечения', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_primary_button_link',
					'label'         => __('Primary Button Link', 'ichilovtop'),
					'name'          => 'hero_primary_button_link',
					'type'          => 'url',
					'default_value' => '#contact',
				),
				array(
					'key'           => 'field_ich_secondary_button_text',
					'label'         => __('Secondary Button Text', 'ichilovtop'),
					'name'          => 'hero_secondary_button_text',
					'type'          => 'text',
					'default_value' => __('Узнать стоимость', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_secondary_button_link',
					'label'         => __('Secondary Button Link', 'ichilovtop'),
					'name'          => 'hero_secondary_button_link',
					'type'          => 'url',
					'default_value' => '#price',
				),
				array(
					'key'           => 'field_ich_hero_contact_title',
					'label'         => __('Hero Contact Title', 'ichilovtop'),
					'name'          => 'hero_contact_title',
					'type'          => 'text',
					'default_value' => __('Связаться с международным отделом', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_hero_contact_text',
					'label'         => __('Hero Contact Text', 'ichilovtop'),
					'name'          => 'hero_contact_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Телефон, WhatsApp и первичный разбор медицинских документов доступны для иностранных пациентов.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_hero_stats',
					'label'      => __('Hero Stats', 'ichilovtop'),
					'name'       => 'hero_stats',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Stat', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_hero_stat_value',
							'label'=> __('Value', 'ichilovtop'),
							'name' => 'value',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_hero_stat_label',
							'label'=> __('Label', 'ichilovtop'),
							'name' => 'label',
							'type' => 'text',
						),
					),
				),
				array(
					'key'        => 'field_ich_hero_badges',
					'label'      => __('Hero Badges', 'ichilovtop'),
					'name'       => 'hero_badges',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Badge', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_hero_badge_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_hero_badge_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 2,
						),
					),
				),
				array(
					'key'   => 'field_ich_advantages_tab',
					'label' => __('Advantages', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_advantages_title',
					'label'         => __('Advantages Title', 'ichilovtop'),
					'name'          => 'advantages_title',
					'type'          => 'text',
					'default_value' => __('Почему пациенты выбирают Ichilov Top', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_advantages_text',
					'label'         => __('Advantages Description', 'ichilovtop'),
					'name'          => 'advantages_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Мы собрали ключевые преимущества медицинского сервиса, ориентированного на результат, скорость и удобство для иностранных пациентов.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_advantages_list',
					'label'      => __('Advantages Items', 'ichilovtop'),
					'name'       => 'advantages',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Advantage', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_advantage_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_advantage_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 3,
						),
					),
				),
				array(
					'key'   => 'field_ich_treatments_tab',
					'label' => __('Treatments', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_treatments_title',
					'label'         => __('Treatments Title', 'ichilovtop'),
					'name'          => 'treatments_title',
					'type'          => 'text',
					'default_value' => __('Основные направления лечения', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_treatments_text',
					'label'         => __('Treatments Description', 'ichilovtop'),
					'name'          => 'treatments_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Сфокусировали главные медицинские направления, востребованные у пациентов, обращающихся за лечением в Израиль.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_treatments_highlight_title',
					'label'         => __('Treatments Sidebar Title', 'ichilovtop'),
					'name'          => 'treatments_highlight_title',
					'type'          => 'text',
					'default_value' => __('Комплексный подход к лечению', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_treatments_highlight_text',
					'label'         => __('Treatments Sidebar Text', 'ichilovtop'),
					'name'          => 'treatments_highlight_text',
					'type'          => 'textarea',
					'rows'          => 4,
					'default_value' => __('Для каждого пациента формируется индивидуальный медицинский маршрут: консультации, исследования, хирургия, лекарственная терапия и восстановление.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_treatments_list',
					'label'      => __('Treatments Items', 'ichilovtop'),
					'name'       => 'treatments',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Treatment', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_treatment_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_treatment_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 3,
						),
					),
				),
				array(
					'key'   => 'field_ich_diagnostics_tab',
					'label' => __('Diagnostics', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_diagnostics_title',
					'label'         => __('Diagnostics Title', 'ichilovtop'),
					'name'          => 'diagnostics_title',
					'type'          => 'text',
					'default_value' => __('Диагностика и второе мнение', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_diagnostics_text',
					'label'         => __('Diagnostics Description', 'ichilovtop'),
					'name'          => 'diagnostics_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Быстрая и точная диагностика помогает подтвердить диагноз, выявить риски и подобрать максимально эффективную тактику лечения.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_diagnostics_sidebar_title',
					'label'         => __('Diagnostics Sidebar Title', 'ichilovtop'),
					'name'          => 'diagnostics_sidebar_title',
					'type'          => 'text',
					'default_value' => __('Что включает диагностическая программа', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_diagnostics_sidebar_list',
					'label'         => __('Diagnostics Sidebar List', 'ichilovtop'),
					'name'          => 'diagnostics_sidebar_list',
					'type'          => 'textarea',
					'rows'          => 5,
					'default_value' => __("Консультации профильных врачей\nЛабораторные и визуализационные исследования\nПересмотр гистологии и снимков\nФинальное заключение и рекомендации", 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_diagnostics_items',
					'label'      => __('Diagnostics Items', 'ichilovtop'),
					'name'       => 'diagnostics',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Diagnostic Item', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_diagnostic_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_diagnostic_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 3,
						),
					),
				),
				array(
					'key'   => 'field_ich_steps_tab',
					'label' => __('Steps', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_steps_title',
					'label'         => __('Steps Title', 'ichilovtop'),
					'name'          => 'steps_title',
					'type'          => 'text',
					'default_value' => __('Как проходит лечение с Ichilov Top', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_steps_text',
					'label'         => __('Steps Description', 'ichilovtop'),
					'name'          => 'steps_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Пошаговый маршрут помогает заранее понимать сроки, бюджет и порядок действий.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_steps_items',
					'label'      => __('Steps Items', 'ichilovtop'),
					'name'       => 'steps',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Step', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_step_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_step_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 3,
						),
					),
				),
				array(
					'key'   => 'field_ich_price_tab',
					'label' => __('Price', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_price_title',
					'label'         => __('Price Title', 'ichilovtop'),
					'name'          => 'price_title',
					'type'          => 'text',
					'default_value' => __('Стоимость и финансовая прозрачность', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_price_text',
					'label'         => __('Price Description', 'ichilovtop'),
					'name'          => 'price_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Итоговая стоимость зависит от диагноза, объема диагностики, необходимости операции и выбранной программы лечения.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_price_value',
					'label'         => __('Price Highlight Value', 'ichilovtop'),
					'name'          => 'price_value',
					'type'          => 'text',
					'default_value' => __('Индивидуальный расчет', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_price_note',
					'label'         => __('Price Note', 'ichilovtop'),
					'name'          => 'price_note',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('После изучения документов мы подготавливаем предварительную смету и объясняем, из каких этапов она состоит.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_price_items',
					'label'      => __('Price List', 'ichilovtop'),
					'name'       => 'price_items',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Price Item', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_price_item',
							'label'=> __('Item', 'ichilovtop'),
							'name' => 'item',
							'type' => 'text',
						),
					),
				),
				array(
					'key'   => 'field_ich_international_tab',
					'label' => __('International Patients', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_international_title',
					'label'         => __('International Title', 'ichilovtop'),
					'name'          => 'international_title',
					'type'          => 'text',
					'default_value' => __('Сервис для иностранных пациентов', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_international_text',
					'label'         => __('International Description', 'ichilovtop'),
					'name'          => 'international_text',
					'type'          => 'textarea',
					'rows'          => 4,
					'default_value' => __('Мы понимаем, что лечение за границей требует не только сильной медицины, но и понятной организации поездки. Поэтому пациент получает не просто медицинский маршрут, а полноценную поддержку.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_international_sidebar_title',
					'label'         => __('International Sidebar Title', 'ichilovtop'),
					'name'          => 'international_sidebar_title',
					'type'          => 'text',
					'default_value' => __('Что мы берем на себя', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_international_sidebar_text',
					'label'         => __('International Sidebar Text', 'ichilovtop'),
					'name'          => 'international_sidebar_text',
					'type'          => 'textarea',
					'rows'          => 4,
					'default_value' => __('Коммуникация с клиникой, запись на приемы, помощь с организацией прибытия и сопровождение на месте.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_international_benefits',
					'label'      => __('International Benefits', 'ichilovtop'),
					'name'       => 'international_benefits',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add Benefit', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_international_benefit_title',
							'label'=> __('Title', 'ichilovtop'),
							'name' => 'title',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_international_benefit_text',
							'label'=> __('Text', 'ichilovtop'),
							'name' => 'text',
							'type' => 'textarea',
							'rows' => 3,
						),
					),
				),
				array(
					'key'   => 'field_ich_faq_tab',
					'label' => __('FAQ', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_faq_title',
					'label'         => __('FAQ Title', 'ichilovtop'),
					'name'          => 'faq_title',
					'type'          => 'text',
					'default_value' => __('Частые вопросы', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_faq_text',
					'label'         => __('FAQ Description', 'ichilovtop'),
					'name'          => 'faq_text',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __('Собрали ответы на основные вопросы пациентов, планирующих диагностику или лечение в Израиле.', 'ichilovtop'),
				),
				array(
					'key'        => 'field_ich_faq_items',
					'label'      => __('FAQ Items', 'ichilovtop'),
					'name'       => 'faq',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => __('Add FAQ', 'ichilovtop'),
					'sub_fields' => array(
						array(
							'key'  => 'field_ich_faq_question',
							'label'=> __('Question', 'ichilovtop'),
							'name' => 'question',
							'type' => 'text',
						),
						array(
							'key'  => 'field_ich_faq_answer',
							'label'=> __('Answer', 'ichilovtop'),
							'name' => 'answer',
							'type' => 'textarea',
							'rows' => 4,
						),
					),
				),
				array(
					'key'   => 'field_ich_cta_tab',
					'label' => __('CTA / Contact', 'ichilovtop'),
					'type'  => 'tab',
				),
				array(
					'key'           => 'field_ich_cta_title',
					'label'         => __('CTA Title', 'ichilovtop'),
					'name'          => 'cta_title',
					'type'          => 'text',
					'default_value' => __('Получите персональный план диагностики или лечения', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_cta_text',
					'label'         => __('CTA Text', 'ichilovtop'),
					'name'          => 'cta_text',
					'type'          => 'textarea',
					'rows'          => 4,
					'default_value' => __('Отправьте документы, и мы поможем сориентироваться по срокам, врачам, стоимости и организационным вопросам.', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_cta_primary_text',
					'label'         => __('CTA Primary Button Text', 'ichilovtop'),
					'name'          => 'cta_primary_text',
					'type'          => 'text',
					'default_value' => __('Отправить запрос', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_cta_primary_link',
					'label'         => __('CTA Primary Button Link', 'ichilovtop'),
					'name'          => 'cta_primary_link',
					'type'          => 'url',
					'default_value' => 'mailto:info@ichilovtop.ru',
				),
				array(
					'key'           => 'field_ich_cta_secondary_text',
					'label'         => __('CTA Secondary Button Text', 'ichilovtop'),
					'name'          => 'cta_secondary_text',
					'type'          => 'text',
					'default_value' => __('Позвонить', 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_cta_secondary_link',
					'label'         => __('CTA Secondary Button Link', 'ichilovtop'),
					'name'          => 'cta_secondary_link',
					'type'          => 'url',
					'default_value' => 'tel:+97233760391',
				),
				array(
					'key'           => 'field_ich_contact_phone',
					'label'         => __('Contact Phone', 'ichilovtop'),
					'name'          => 'contact_phone',
					'type'          => 'text',
					'default_value' => '+972-3-376-0391',
				),
				array(
					'key'           => 'field_ich_contact_email',
					'label'         => __('Contact Email', 'ichilovtop'),
					'name'          => 'contact_email',
					'type'          => 'email',
					'default_value' => 'info@ichilovtop.ru',
				),
				array(
					'key'           => 'field_ich_contact_address',
					'label'         => __('Contact Address', 'ichilovtop'),
					'name'          => 'contact_address',
					'type'          => 'textarea',
					'rows'          => 3,
					'default_value' => __("Израиль, Тель-Авив\nул. Вайцман, 14", 'ichilovtop'),
				),
				array(
					'key'           => 'field_ich_contact_schedule',
					'label'         => __('Contact Schedule', 'ichilovtop'),
					'name'          => 'contact_schedule',
					'type'          => 'text',
					'default_value' => __('Ежедневно, 08:00-20:00', 'ichilovtop'),
				),
			),
			'location' => array(
				array(
					array(
						'param'    => 'page_type',
						'operator' => '==',
						'value'    => 'front_page',
					),
				),
			),
		)
	);
}
add_action('acf/init', 'ichilovtop_register_acf_fields');
